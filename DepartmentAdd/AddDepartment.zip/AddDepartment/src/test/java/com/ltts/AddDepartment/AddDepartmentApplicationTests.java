package com.ltts.AddDepartment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
